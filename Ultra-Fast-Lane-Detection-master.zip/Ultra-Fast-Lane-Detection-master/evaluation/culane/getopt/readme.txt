For windows build, `getopt.c` and `getopt.h` are required. 

They are taken from the [iotivity](https://github.com/iotivity/iotivity) open source project, under Apache LICENSE 2.0.